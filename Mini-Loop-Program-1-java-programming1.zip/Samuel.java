import java.util.Scanner;
class Main {
  public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
int count = 1; 
int hashtagValue = scan.nextInt();
int sum = 0; 


while (count < 11 && hashtagValue != 0)
  {
    count += 1;
    System.out.println("Please input a number " + hashtagValue);
    sum += hashtagValue;
    hashtagValue = scan.nextInt();
  }
  System.out.println("The sum of the numbers is " + sum);
  }
}