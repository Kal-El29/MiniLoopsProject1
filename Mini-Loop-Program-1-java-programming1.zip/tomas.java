import java.util.scanner;
public class main {
  public static void main (string[] args{
    Scanner scan = new scan 
                           
  }
