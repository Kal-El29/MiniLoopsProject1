import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    int counter = 1;
    int num = 1;
    int sum = 0;
    while (counter <= 10 && num != 0) {
      System.out.println("Please enter a number");
      num = scan.nextInt();
      if (num != 0) {
        sum += num;
        counter++;
      }
    }
    System.out.println(sum);
  }
}